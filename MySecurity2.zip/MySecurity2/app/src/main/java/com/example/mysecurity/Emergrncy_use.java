package com.example.mysecurity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Emergrncy_use extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergrncy_use);
    }
}
