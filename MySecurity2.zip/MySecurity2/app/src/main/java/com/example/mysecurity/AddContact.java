package com.example.mysecurity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class AddContact extends AppCompatActivity implements View.OnClickListener {
    TextInputLayout num1,num2,num3,num4,num5;
    Button addContacts;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        num1=findViewById(R.id.phoneNo1);
        num2=findViewById(R.id.phoneNo2);
        num3=findViewById(R.id.phoneNo3);
        num4=findViewById(R.id.phoneNo4);
        num5=findViewById(R.id.phoneNo5);
        addContacts=findViewById(R.id.addContact);
        addContacts.setOnClickListener(this);


            }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.addContact:
                addContactToDatabase();
                break;
        }
    }

    private void addContactToDatabase() {
        String contact1=num1.getEditText().getText().toString();
        String contact2=num2.getEditText().getText().toString();
        String contact3=num3.getEditText().getText().toString();
        String contact4=num4.getEditText().getText().toString();
        String contact5=num5.getEditText().getText().toString();

        if(contact1.isEmpty()){
            num1.setError("Field cannot be empty");
            num1.requestFocus();
            return;
        }
        if(contact2.isEmpty()){
            num2.setError("Field cannot be empty");
            num2.requestFocus();
            return;
        }
        if(contact3.isEmpty()){
            num3.setError("Field cannot be empty");
            num3.requestFocus();
            return;
        }

        UserHelperClass2 userhelperClass2=new UserHelperClass2(contact1,contact2,contact3,contact4,contact5);
        FirebaseDatabase.getInstance().getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .push().child("Contact").setValue(userhelperClass2).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(AddContact.this,"Contacts has been added successfully!",Toast.LENGTH_LONG).show();
                    startActivity(new Intent(AddContact.this,UserProfile.class));
                }else{
                    Toast.makeText(AddContact.this,"Failed to add contacts",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
