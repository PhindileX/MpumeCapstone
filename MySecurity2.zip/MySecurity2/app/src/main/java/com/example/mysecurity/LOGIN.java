package com.example.mysecurity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class LOGIN extends AppCompatActivity implements View.OnClickListener {

    Button CallSignUp,login_Btn,ForgotPassword;
    TextInputLayout email,password;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l_o_g_i_n2);



        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        CallSignUp=findViewById(R.id.callSignUp);
        CallSignUp.setOnClickListener(this);
        login_Btn=findViewById(R.id.login_Btn);
        login_Btn.setOnClickListener(this);
        ForgotPassword=findViewById(R.id.forgotPassword);
        ForgotPassword.setOnClickListener(this);
        progressBar=findViewById(R.id.progressBar);
        mAuth=FirebaseAuth.getInstance();



              }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.callSignUp:
                startActivity(new Intent(this,Sign_in.class));
                break;
            case R.id.login_Btn:
                UserLogin();
                break;
            case R.id.forgotPassword:
                startActivity(new Intent(this,forgotPasswordPage.class));
                break;

        }

    }

    private void UserLogin() {
        String userEnteredEmail = email.getEditText().getText().toString().trim();
        String userEnteredPassword = password.getEditText().getText().toString().trim();

        if(userEnteredEmail.isEmpty()){
            email.setError("Field cannot be empty");
            email.requestFocus();
            return;
        }
        String emailPattern = "[a-zA-Z_0-9._-]+@[a-z]+\\.+[a-z]+";

        if(!userEnteredEmail.matches(emailPattern)){
            email.setError("invalid email address");
            email.requestFocus();
            return;
        }
        if(userEnteredPassword.isEmpty()) {
            password.setError("please enter password");
            password.requestFocus();
            return;
        }
        if (userEnteredPassword.length()<6){
            password.setError("min password length should be 6 characters!");
            password.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(userEnteredEmail,userEnteredPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    startActivity(new Intent(LOGIN.this,UserProfile.class));
                    progressBar.setVisibility(View.GONE);
                }else{
                    Toast.makeText(LOGIN.this,"Use failed to register",Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
    }
}

